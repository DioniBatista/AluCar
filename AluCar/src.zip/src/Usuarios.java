import java.sql.*;
public class Usuarios 
{
	String login;
	String Senha;

}
